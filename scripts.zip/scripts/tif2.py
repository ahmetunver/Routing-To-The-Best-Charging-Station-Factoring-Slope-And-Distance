import rasterio
from rasterio.merge import merge
import matplotlib.pyplot as plt

# Birleştirilecek tif dosyalarının yolları
tif_files = ['C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\srtm_data.tif', 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\srtm_data2.tif']

# Tüm tif dosyalarını aç
src_files_to_mosaic = []
for file in tif_files:
    src = rasterio.open(file)
    src_files_to_mosaic.append(src)

# Tif dosyalarını birleştir
mosaic, out_transform = merge(src_files_to_mosaic)

# Çıktı dosyasının ayarları
out_meta = src.meta.copy()
out_meta.update({
    "driver": "GTiff",
    "height": mosaic.shape[1],
    "width": mosaic.shape[2],
    "transform": out_transform,
})

# Birleştirilmiş tif dosyasını kaydet
output_path = 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\merged_srtm_data.tif'
with rasterio.open(output_path, "w", **out_meta) as dest:
    dest.write(mosaic)

# Sonuçları görselleştir
plt.figure(figsize=(10, 10))
plt.imshow(mosaic[0], cmap='terrain')
plt.colorbar()
plt.title("Birleştirilmiş TIF Verisi")
plt.show()
