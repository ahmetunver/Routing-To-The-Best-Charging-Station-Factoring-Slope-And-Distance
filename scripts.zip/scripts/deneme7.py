import json
import requests
from shapely.geometry import shape, Point
import geopandas as gpd
import rasterio
import numpy as np
import osmnx as ox
import networkx as nx
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import os

# 1. GeoJSON Dosyasını Okuma ve Poligon Oluşturma
def load_geojson(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return shape(data['features'][0]['geometry'])
    except FileNotFoundError:
        print(f"GeoJSON dosyası bulunamadı: {path}")
        raise

geojson_path = os.path.join(os.path.dirname(__file__), 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\export.geojson')
beşiktaş_polygon = load_geojson(geojson_path)

# 2. OpenChargeMap API'den Şarj İstasyonlarını Alma
def fetch_charging_stations(api_key, latitude, longitude, distance):
    url = "https://api.openchargemap.io/v3/poi/"
    params = {
        "output": "json",
        "latitude": latitude,
        "longitude": longitude,
        "distance": distance,
        "distanceunit": "km",
        "key": api_key,
        "maxresults": 100
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"API Hatası: {response.status_code}, {response.text}")
        return []

api_key = "04d10698-1166-4281-9ac3-81676e3b742d"
stations_data = fetch_charging_stations(api_key, 41.041675, 29.0028, 20)

# 3. SRTM Yükseklik Verisini Yükleme
srtm_path = os.path.join(os.path.dirname(__file__), 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\merged_srtm_data.tif')
try:
    srtm_data = rasterio.open(srtm_path)
except rasterio.errors.RasterioIOError:
    print(f"Raster dosyası bulunamadı veya açılamadı: {srtm_path}")
    raise

def calculate_detailed_slope(lat, lon):
    try:
        row, col = srtm_data.index(lon, lat)
        elevation_window = srtm_data.read(1)[max(0, row-1):row+2, max(0, col-1):col+2]
        if elevation_window.size == 0 or np.isnan(elevation_window).all():
            return 0
        x_slope = np.gradient(elevation_window, axis=1)
        y_slope = np.gradient(elevation_window, axis=0)
        slope = np.sqrt(x_slope**2 + y_slope**2).mean()
        return slope
    except IndexError:
        return 0

# 4. Yol Uzunluğu ve Eğim Bazlı Enerji Hesabı
def calculate_energy(distance, slope):
    k1 = 0.2
    k2 = 9.8 * 0.001
    return distance * k1 + (slope * distance) * k2

# 5. Harita ve Ağ Yapısı
besiktas_coords = (41.041675, 29.0028)
G = ox.graph_from_polygon(beşiktaş_polygon, network_type='drive')

start_lat, start_lon = 41.055669, 29.030968
start_node = ox.distance.nearest_nodes(G, start_lon, start_lat)

# 6. Derin Öğrenme Modeli
model = Sequential([
    Dense(64, activation='relu', input_shape=(3,)),  # Mesafe, eğim, enerji
    Dense(32, activation='relu'),
    Dense(1, activation='sigmoid')  # Uygunluk (0 ile 1 arasında)
])
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Eğitim Verisi (Mesafe, eğim ve enerjiye bağlı olarak uygunluk)
X_train = np.array([
    [1.0, 0.1, 0.1],
    [2.0, 0.05, 0.6],
    [1.5, 0.2, 0.3],
    [3.0, 0.3, 1.0],
    [0.5, 0.1, 0.05],
    [4.0, 0.4, 1.5],
    [2.5, 0.15, 0.4],
    [1.8, 0.25, 0.35]
])
y_train = np.array([1, 0, 1, 0, 1, 0, 1, 0])  # Uygunluk etiketleri

# Modeli Eğit
history = model.fit(X_train, y_train, epochs=100, batch_size=32, verbose=1)

# 7. İstasyon Seçimi
stations_in_besiktas = []
for station in stations_data:
    try:
        address_info = station.get('AddressInfo', {})
        lat = address_info.get('Latitude')
        lon = address_info.get('Longitude')
        if lat and lon:
            point = Point(lon, lat)
            if beşiktaş_polygon.contains(point):
                slope = calculate_detailed_slope(lat, lon)
                target_node = ox.distance.nearest_nodes(G, lon, lat)
                try:
                    distance = nx.shortest_path_length(G, start_node, target_node, weight='length') / 1000  # km
                    energy = calculate_energy(distance, slope)
                    stations_in_besiktas.append((lon, lat, slope, distance, energy, target_node))
                except nx.NetworkXNoPath:
                    print(f"Node {target_node} not reachable from {start_node}. Skipping this station.")
                    continue
    except Exception as e:
        print(f"Unexpected error: {e}")

# 8. En Uygun İstasyonun Seçimi (Enerji Bazlı)
def select_best_station_with_energy(stations):
    if not stations:
        print("Uygun istasyon bulunamadı.")
        return None
    min_energy_station = min(stations, key=lambda s: s[4])  # Enerji sırasına göre
    return min_energy_station

best_station = select_best_station_with_energy(stations_in_besiktas)
if best_station:
    print(f"En düşük enerji istasyonu: {best_station}")

# 9. Harita Görselleştirme
def visualize_map(stations, best_station):
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_title("Beşiktaş Bölgesi ve Şarj İstasyonları", fontsize=15)

    beşiktaş_gdf = gpd.GeoDataFrame(geometry=[beşiktaş_polygon])
    beşiktaş_gdf.plot(ax=ax, edgecolor='black', facecolor='lightblue', alpha=0.5, linewidth=1)

    # Başlangıç noktasını göster
    ax.scatter(start_lon, start_lat, color='green', s=100, label="Araç Konumu", zorder=5)

    # Şarj istasyonlarını göster ve yanına eğim ve enerji bilgisini ekle
    for lon, lat, slope, distance, energy, target_node in stations:
        color = 'red' if (lon, lat) == (best_station[0], best_station[1]) else 'gray'
        ax.scatter(lon, lat, color=color, s=50, label=f" Şarj İstasyonu Eğim: {slope:.2f}, Enerji: {energy:.2f}", zorder=5)

    if best_station:
        # En uygun istasyona olan rotayı çiz
        best_target_node = best_station[-1]
        try:
            route = nx.shortest_path(G, start_node, best_target_node, weight='length')
            coords = [(G.nodes[node]['x'], G.nodes[node]['y']) for node in route]
            coords.append((best_station[0], best_station[1]))  # Şarj istasyonu tam koordinatı
            x, y = zip(*coords)
            ax.plot(x, y, color='blue', linewidth=2, zorder=4, label="En Uygun Rota")
        except nx.NetworkXNoPath:
            print("Rota bulunamadı, uygun bir yol yok.")

    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.legend()
    plt.grid(True)
    plt.show()
    # Kaydet
    fig.savefig("C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\deneme7_7.png", dpi=300)
    plt.close(fig)
    print("Grafik başarıyla kaydedildi.")


if best_station:
    visualize_map(stations_in_besiktas, best_station)

# 10. Doğruluk ve Kayıp Grafikleri
plt.figure(figsize=(12, 6))

# Doğruluk ve kayıp grafiği
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Doğruluk (Accuracy)')
plt.xlabel('Epoch')
plt.ylabel('Doğruluk')
plt.legend()
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Kayıp (Loss)', color='red')
plt.xlabel('Epoch')
plt.ylabel('Kayıp')
plt.legend()
plt.grid(True)

plt.suptitle("Model Eğitimi - Doğruluk ve Kayıp", fontsize=16)

# 11. Sensitivity, Specificity Hesaplama
predictions = (model.predict(X_train) > 0.5).astype(int)
conf_matrix = confusion_matrix(y_train, predictions)
TN, FP, FN, TP = conf_matrix.ravel()
accuracy = (TP + TN) / (TP + TN + FP + FN)
sensitivity = TP / (TP + FN)
specificity = TN / (TN + FP)


# Performans metriklerini grafik üzerine ekleyip kaydetme
plt.figtext(0.15, 0.01, f"Accuracy: {accuracy * 100:.2f}% | Sensitivity: {sensitivity * 100:.2f}% | Specificity: {specificity * 100:.2f}%", 
            wrap=True, horizontalalignment='left', fontsize=14)

# Grafiği Kaydet
plt.tight_layout(rect=[0, 0.1, 1, 0.95])  # Grafik düzeni ayarları
# Grafiği Kaydet
output_path = 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\deneme7_grafik.png'
plt.savefig(output_path, dpi=300)

# Grafik Gösterimi
plt.show()

print(f"Grafik başarıyla kaydedildi: {output_path}")

print(f"Accuracy: {accuracy * 100:.2f}%")
print(f"Sensitivity: {sensitivity * 100:.2f}%")
print(f"Specificity: {specificity * 100:.2f}%")

