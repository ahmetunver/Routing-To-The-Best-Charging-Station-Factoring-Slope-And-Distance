import rasterio
from rasterio.transform import from_origin

# HGT dosyasını açma ve TIF'e çevirme
hgt_path = 'C:\\Users\\asus\\OneDrive\\Desktop\\NASADEM_HGT_n41e029\\n41e029.hgt'
tif_path = 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\srtm_data2.tif'

with rasterio.open(hgt_path) as src:
    profile = src.profile
    profile.update(driver='GTiff')
    
    with rasterio.open(tif_path, 'w', **profile) as dst:
        dst.write(src.read(1), 1)
