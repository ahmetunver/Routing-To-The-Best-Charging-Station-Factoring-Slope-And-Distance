import json
import requests
from shapely.geometry import shape, Point
import matplotlib.pyplot as plt
import geopandas as gpd

# 1. GeoJSON Dosyasını Okuma ve Poligon Oluşturma
geojson_path = 'C:\\Users\\asus\\OneDrive\\Desktop\\Pyhton\\finalproje\\export.geojson'
with open(geojson_path, 'r', encoding='utf-8') as f:
    geojson_data = json.load(f)

# Beşiktaş poligonunu oluştur
beşiktaş_polygon = shape(geojson_data['features'][0]['geometry'])

# 2. OpenChargeMap API'den Şarj İstasyonlarını Alma
api_key = "04d10698-1166-4281-9ac3-81676e3b742d"
url = "https://api.openchargemap.io/v3/poi/"
params = {
    "output": "json",
    "latitude": 41.041675,  # Beşiktaş'ın merkezi
    "longitude": 29.0028,
    "distance": 20,  # 20 km'lik bir alan
    "distanceunit": "km",
    "key": api_key,
    "maxresults": 100
}

response = requests.get(url, params=params)

# API isteği başarılıysa
if response.status_code == 200:
    data = response.json()

    # Beşiktaş sınırları içindeki şarj istasyonlarını filtrele
    stations_in_besiktas = []
    for station in data:
        address_info = station.get('AddressInfo', {})
        lat = address_info.get('Latitude')
        lon = address_info.get('Longitude')

        if lat and lon:
            point = Point(lon, lat)
            if beşiktaş_polygon.contains(point):  # Poligonun içinde mi?
                stations_in_besiktas.append((lon, lat))

    # 3. Harita Görselleştirme
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.set_title("Beşiktaş Bölgesi ve Şarj İstasyonları", fontsize=15)

    # Beşiktaş poligonunu çiz
    beşiktaş_gdf = gpd.GeoDataFrame(geometry=[beşiktaş_polygon])
    beşiktaş_gdf.plot(ax=ax, edgecolor='black', facecolor='lightblue', alpha=0.5, linewidth=1)

    # Şarj istasyonlarını çiz
    if stations_in_besiktas:
        for lon, lat in stations_in_besiktas:
            ax.scatter(lon, lat, color='red', s=50, label="Şarj İstasyonu", zorder=5)

        plt.legend(["Şarj İstasyonu"])
    else:
        print("Beşiktaş sınırları içinde şarj istasyonu bulunamadı.")

    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.grid(True)
    plt.savefig('besiktasSINIRIsarj.png', dpi=300)
    plt.show()

else:
    print(f"API Hatası: {response.status_code}, {response.text}")
